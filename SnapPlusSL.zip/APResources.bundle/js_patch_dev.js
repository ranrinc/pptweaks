defineClass('VENTouchLock', {
    isPasscodeSet: function() {
        return false;
    },
});