require('UIWebView');
defineClass('UAAdManager', {
    adViewDidLoadAd: function(view) {
        var webView = view.ua__firstSubviewOfClass(UIWebView.class());
        if (webView) { webView.scrollView().setContentInsetAdjustmentBehavior(2); }
        self.ORIGadViewDidLoadAd(view);
    },
});